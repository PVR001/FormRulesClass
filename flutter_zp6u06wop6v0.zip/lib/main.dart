import 'package:flutter/material.dart';
import 'package:rules/rules.dart';
import 'package:fluttertoast/fluttertoast.dart';


extension DisableInput on Rule {
  bool shouldDisableInput() {
    // Check for a specific condition to disable input (e.g., rule name)
    return this.name == 'DisallowInputRule';
  }
}

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          title: Text('Form rules'),
        ),
        body: MyForm(),
      ),
    );
  }
}

class MyForm extends StatefulWidget {
  @override
  _MyFormState createState() => _MyFormState();
}

class _MyFormState extends State<MyForm> {
  @override
  void initState() {
    super.initState();
  }

  // Define TextEditingController for each TextFormField
  final TextEditingController serialNumberController = TextEditingController();
  final TextEditingController nameController = TextEditingController();
  final TextEditingController phoneNumberController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController addressController = TextEditingController();
  final TextEditingController cityController = TextEditingController();
  final TextEditingController pincodeController = TextEditingController();
  final TextEditingController stateController = TextEditingController();
  final TextEditingController countryController = TextEditingController();
  bool validsl = false;
  bool validname=false;
  bool validPh=false;
  bool validMail=false;
  bool validAdd=false;
  bool validCity=false;
  bool validPin=false;
  bool validState=false;
  bool validCountry=false;


  

  @override
  void dispose() {
    // Dispose the controllers to free up resources
    serialNumberController.dispose();
    nameController.dispose();
    phoneNumberController.dispose();
    emailController.dispose();
    addressController.dispose();
    cityController.dispose();
    pincodeController.dispose();
    stateController.dispose();
    countryController.dispose();
    super.dispose();
  }

  void showToast(String message) {
    Fluttertoast.showToast(
      msg: message,
      toastLength: Toast.LENGTH_LONG,
      gravity: ToastGravity.BOTTOM,
      backgroundColor: Colors.red,
      textColor: Colors.white,
    );
  }

  void processFormData() {
    // Access and process the entered data
    final serialNumber = serialNumberController.text;
    final names = nameController.text;
    final phoneNumber = phoneNumberController.text;
    final email = emailController.text;
    final address = addressController.text;
    final city = cityController.text;
    final pincode = pincodeController.text;
    final state = stateController.text;
    final country = countryController.text;

    // You can now use the data as needed, e.g., save to a database, display, or perform any actions.
    // print('Serial Number: $serialNumber');
    // print('Name: $names');
    // print('Phone Number: $phoneNumber');
    // print('Email: $email');
    // print('Address: $address');
    // print('City: $city');
    // print('Pincode: $pincode');
    // print('State: $state');
    // print('Country: $country');
    notEmptyField();
    slNumberRules();
    nameRules();
    phoneNumberRules();
    emailRules();
    addressRules();
    cityRules();
    pincodeRules();
    stateRules();
    countryRules();
  }

  void notEmptyField() {
    final slNotNull = Rule(serialNumberController.text,
        name: 'Text field 1', isRequired: true);
    final nameNotNull =
        Rule(nameController.text, name: 'Text field 2', isRequired: true);
    final phNotNull = Rule(phoneNumberController.text,
        name: 'Text field 3', isRequired: true);
    final mailNotNull =
        Rule(emailController.text, name: 'Text field 4', isRequired: true);

    final addressNotNull =
        Rule(addressController.text, name: 'Text field 5', isRequired: true);
    final cityNotNull =
        Rule(cityController.text, name: 'Text field 6', isRequired: true);
    final pinNotNull =
        Rule(pincodeController.text, name: 'Text field 7', isRequired: true);
    final stateNotNull =
        Rule(stateController.text, name: 'Text field 8', isRequired: true);
    final countryNotNull =
        Rule(countryController.text, name: 'Text filed 9', isRequired: true);
    final notNullGroupRule = GroupRule([
      slNotNull,
      nameNotNull,
      mailNotNull,
      addressNotNull,
      cityNotNull,
      pinNotNull,
      stateNotNull,
      countryNotNull
    ], name: 'notNullGroup', requiredAll: true);

    if (notNullGroupRule.hasError) {
      // showToast("All fields are empty");
    }
  }

  void slNumberRules() {
    final slNotNull = Rule(
      serialNumberController.text,
      name: 'Serial number',
      isRequired: true,
    );

    final slNotAlpha = Rule(serialNumberController.text,
        name: 'Serial number',
        isNumeric: true,
        customErrorText: '{value} is not a valid {name}');

    if (slNotNull.hasError) {
      showToast(slNotNull.error!);
      validsl = false;
      print(slNotNull.error);
    } else if (slNotAlpha.hasError) {
      validsl = false;
      print(slNotAlpha.error);
      showToast(slNotAlpha.error!);
    } else {
      print('Serial number is valid');
      setState(() {
        validsl = true;
      });
    }
  }

  void nameRules() {
    final nameNotNull = Rule(
      nameController.text,
      name: 'name ',
      isRequired: true,
    );
    final nameAlpha = Rule(nameController.text,
        name: 'name',
        isAlphaSpace: true,
        customErrorText: '{value} is not a valid {name}');
    if (nameNotNull.hasError) {
      showToast(nameNotNull.error!);
      print(nameNotNull.error);
    } else if (nameAlpha.hasError) {
      print(nameAlpha.error);
      showToast(nameAlpha.error!);
    } else {
      setState(() {
        validname = true;
      });
      print('name is valid');
    }
  }

  void phoneNumberRules() {
    final phoneNumber = phoneNumberController.text;
    final phNotNull = Rule(
      phoneNumber,
      name: 'Phone Number',
      isRequired: true,
    );

    final phNumeric = Rule(phoneNumber,
        name: 'Phone Number',
        isPhone: true,
        customErrorText: '{value} is not a valid {name}');

    if (phNotNull.hasError) {
      showToast(phNotNull.error!);
      print(phNotNull.error);
    } else if (phNumeric.hasError) {
      showToast(phNumeric.error!);
      print(phNumeric.error);
    } else {
      print('Phone number is valid');
      setState(() {
        validPh = true;
      });
    }
  }

  void emailRules() {
    final emailNotNull = Rule(
      emailController.text,
      name: 'mail',
      isRequired: true,
    );

    final mailRule = Rule(
      emailController.text,
      name: 'entered mail',
      isEmail: true,
    );

    if (emailNotNull.hasError) {
      showToast(emailNotNull.error!);
      print(emailNotNull.error);
    } else if (mailRule.hasError) {
      showToast(mailRule.error!);
      print(mailRule.error);
    } else {
      print('Email  is valid');
      setState(() {
        validMail = true;
      });
    }
  }

  void addressRules() {
    final addressNotNull =
        Rule(addressController.text, name: 'Address', isRequired: true);
    if (addressNotNull.hasError) {
      print('Address is required');
      showToast(addressNotNull.error!);
    }else{
      setState(() {
        validAdd = true;
      });
    }
  }

  void cityRules() {
    final cityNotNull =
        Rule(cityController.text, name: 'City', isRequired: true);
    if (cityNotNull.hasError) {
      print('City is required');
      showToast(cityNotNull.error!);
    }else{
      setState(() {
        validCity = true;
      });
    }
  }

  void pincodeRules() {
    final pinNotNull =
        Rule(pincodeController.text, name: 'Pincode', isRequired: true);
    final validPinRule =
        Rule(pincodeController.text, name: 'Pincode', isNumeric: true);
    if (pinNotNull.hasError) {
      showToast(pinNotNull.error!);
      print('Pincode is required');
    } else if (validPinRule.hasError) {
      print('Pincode is not a valid number');
      showToast(validPinRule.error!);
    }
    else{
      setState(() {
        validPin = true;
      });
    }
  }

  void stateRules() {
    final stateNotNull = Rule(
      stateController.text,
      name: 'state',
      isRequired: true,
    );

    final stateRule = Rule(
      stateController.text,
      name: 'state',
      isAlphaSpace: true,
      customErrorText: '{value} is not a  valid {name}',
    );

    if (stateNotNull.hasError) {
      showToast(stateNotNull.error!);
      print(stateNotNull.error);
    } else if (stateRule.hasError) {
      showToast(stateRule.error!);
      print(stateRule.error);
    } else {
      print('state is valid');
      setState(() {
        validState = true;
      });
    }
  }

  void countryRules() {
    final countryNotNull = Rule(
      countryController.text,
      name: 'country',
      isRequired: true,
    );

    final countryRule = Rule(
      countryController.text,
      name: 'country',
      isAlphaSpace: true,
      customErrorText: '{value} is not a  valid {name}',
    );

    if (countryNotNull.hasError) {
      showToast(countryNotNull.error!);
      print(countryNotNull.error);
    } else if (countryRule.hasError) {
      showToast(countryRule.error!);
      print(countryRule.error);
    } else {
    success();

      print('country is valid');
      setState(() {
        validCountry = true;
      });
    }
  }
void success(){
  if(validname==true && validsl==true && validPh==true && validMail==true && validAdd==true && validCity==true && validPin==true && validState==true ){
    showToast("Form submitted Successfully");
  }
  dumpStates();
}

void dumpStates(){
  validname=false;
  validsl=false;
  validPh=false;
  validAdd=false;
  validCity=false;
  validMail=false;
  validPin=false;
  validState=false;
  
  
}
  @override
  Widget build(BuildContext context) {
    
    final disableInput = Rule(
  countryController.text,
  name: 'DisallowInputRule', // Set the rule name to 'DisallowInputRule'
  isNumeric: true, 
  customErrorText: 'Only numbers allowed',
);
    return Padding(
      padding: const EdgeInsets.all(5.0),
      child: Center(
        child: Container(
          width: 450,
          child: Card(
            elevation: 4,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10.0),
            ),
            color: Color(0xFFFAF9F6),
            child: Center(
              // Set the background color to grey
              child: Padding(
                  padding: const EdgeInsets.all(5.0),
                  child: Container(
                    width: 300,
                    child: Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(
                              bottom: 5.0), // Add space at the bottom
                          child: TextFormField(
                            controller: serialNumberController,
                            decoration: InputDecoration(
                              labelText: 'Serial Number',
                              border: OutlineInputBorder(
                                  borderSide: BorderSide(color: Colors.black)),
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(
                              bottom: 5.0), // Add space at the bottom
                          child: TextFormField(
                            controller: nameController,
                            decoration: InputDecoration(
                              labelText: 'Name',
                              border: OutlineInputBorder(
                                  borderSide: BorderSide(color: Colors.black)),
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(
                              bottom: 5.0), // Add space at the bottom
                          child: TextFormField(
                            controller: phoneNumberController,
                            decoration: InputDecoration(
                              labelText: 'Phone Number',
                              border: OutlineInputBorder(
                                  borderSide: BorderSide(color: Colors.black)),
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(
                              bottom: 5.0), // Add space at the bottom
                          child: TextFormField(
                            controller: emailController,
                            decoration: InputDecoration(
                              labelText: 'Email',
                              border: OutlineInputBorder(
                                  borderSide: BorderSide(color: Colors.black)),
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(
                              bottom: 5.0), // Add space at the bottom
                          child: TextFormField(
                            controller: addressController,
                            decoration: InputDecoration(
                              labelText: 'Address',
                              border: OutlineInputBorder(
                                  borderSide: BorderSide(color: Colors.black)),
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(
                              bottom: 5.0), // Add space at the bottom
                          child: TextFormField(
                            controller: cityController,
                            decoration: InputDecoration(
                              labelText: 'City',
                              border: OutlineInputBorder(
                                  borderSide: BorderSide(color: Colors.black)),
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(
                              bottom: 5.0), // Add space at the bottom
                          child: TextFormField(
                            controller: pincodeController,
                            decoration: InputDecoration(
                              labelText: 'Pincode',
                              border: OutlineInputBorder(
                                  borderSide: BorderSide(color: Colors.black)),
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(
                              bottom: 5.0), // Add space at the bottom
                          child: TextFormField(
                            controller: stateController,
                            decoration: InputDecoration(
                              labelText: 'State',
                              border: OutlineInputBorder(
                                  borderSide: BorderSide(color: Colors.black)),
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(
                              bottom: 5.0), // Add space at the bottom
                          child: TextFormField(
                            controller: countryController,
                            decoration: InputDecoration(
                              labelText: 'Country',
                              enabled: disableInput.shouldDisableInput(),
                              border: OutlineInputBorder(
                                  borderSide: BorderSide(color: Colors.black)),
                            ),
                          ),
                        ),
                        SizedBox(height: 16),
                        ElevatedButton(
                          onPressed: processFormData,
                          child: Text('Submit'),
                        ),
                      ],
                    ),
                  )),
            ),
          ),
        ),
      ),
    );
  }
}
